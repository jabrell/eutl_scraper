this zip file includes two csv files : 
	transactions_EUTL_PUBLIC_ESD_20241009.csv
	transactions_EUTL_PUBLIC_NOTESD_20241009.csv

NB :
	ESD stands for "Effort Sharing Decision"
	2024-10-09 is the date data was extracted from EUTL PUBLIC
	transactions_EUTL_PUBLIC_NOTESD_20241009.csv holds 1,875,818 lines (not counting the header line) for 1,139,520 distinct transactions

the reason why a same transaction (with one TRANSACTION_ID) is described by multiple lines is because the file details transactions by ORIGINATING_REGISTRY, UNIT_TYPE_DESCRIPTION, SUPP_UNIT_TYPE_DESCRIPTION, ORIGINAL_PERIOD_CODE, LULUCF_CODE_DESCRIPTION, PROJECT_IDENTIFIER, TRACK and EXPIRY_DATE, which can be many for one transaction
